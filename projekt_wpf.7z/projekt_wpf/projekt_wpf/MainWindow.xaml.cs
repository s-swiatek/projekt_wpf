﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace projekt_wpf
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    class Osoba
    {
        public string? PESEL { get; set; }
        public string? Imie { get; set; }
        public string? drImie { get; set; }
        public string? Nazw { get; set; }
        public string? Urodz { get; set; }
        public string? Numer { get; set; }
        public string? Adres { get; set; }
        public string? Miejs { get; set; }
        public string? Kod { get; set; }
        public Osoba()
        {
            PESEL = "00000000000";
            Imie = "";
            drImie = "";
            Nazw = "";
            Urodz = "";
            Numer = "";
            Adres = "";
            Miejs = "Tarnow";
            Kod = "33-100";

        }
    }
    public partial class MainWindow : Window
    {

        public MainWindow()
        {
            InitializeComponent();
        }

        private void Dodaj_Click(object sender, RoutedEventArgs e)
        {

            Dodaj_osobe dodaj = new Dodaj_osobe();
            dodaj.ShowDialog();

            Osoba uczen = new();

            //uczen.PESEL = dodaj.PESEL.Text;
            //mainList.Items.Add(uczen);
            
        }
        private void Open_Click(object sender, RoutedEventArgs e)
        {
        }
        private void Save_Click(object sender, RoutedEventArgs e)
        {
        }

        private void Exit_Click(object sender, RoutedEventArgs e)
        {
        }

        private void RemoveSel_Click(object sender, RoutedEventArgs e)
        {
        }

        private void O_programie_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}